productos = {'C-123': ['HP', 15.6, '8GB', 'DD', '1T', 'Intel Core i5', 'Nvidia GTX1050'],
        'C-111': ['lenovo', 14, '4GB', 'SSD', '512GB', 'Intel Core i5', 'Nvidia GTX1050'],
        'C-234': ['Asus', 14, '16GB', 'SSD', '256GB', 'Intel Core i7', 'Nvidia RTX2080Ti'],
        'C-456': ['HP', 15.6, '8GB', 'DD', '1T', 'Intel Core i3', 'integrada'],
        'C-1222': ['Asus', 15.6, '8GB', 'DD', '1T', 'Intel Core i7', 'Nvidia GTX1050'],
        'C-477': ['lenovo', 14, '6GB', 'DD', '1T', 'AMD Ryzen 5', 'integrada'],
        'C-334': ['lenovo', 15.6, '8GB', 'DD', '1T', 'AMD Ryzen 7', 'Nvidia GTX1050'],
        'C-2906': ['Dell', 15.6, '8GB', 'DD', '1T', 'AMD Ryzen 3', 'Nvidia GTX1050']}

stock = {'C-123': [387990,10], 
        'C-111': [327990,4], 
        'C-234': [424990,1],
        'C-456': [664990,21], 
        'C-477': [290890,32], 
        'C-334': [444990,7],
        'C-1222': [749990,2], 
        'C-2906': [349990,1]}

#Funciones
def stock_marca (lst_productos: dict, lst_stock: dict, marca_buscada: str) -> int:
        if marca_buscada in lst_productos.values[0]:
                lst_productos.keys()==lst_stock.keys()
                if lst_stock.values[1]>0:
                        return lst_stock.values(1)
                else:
                        return 0

def busqueda_precio (lst_productos: dict, lst_stock: dict, p_min: int, p_max: int) -> None:
        resultado=False
        for precio in lst_stock.values[0]:
                if p_min<=precio<=p_max:
                        lst_productos.keys()==lst_stock.keys()
                        codigo=lst_productos.keys()
                        marca=lst_productos.values[0]
                        pantalla=lst_productos.values[1]
                        ram=lst_productos.values[2]
                        tipo_memoria=lst_productos.values[3]
                        almacenamiento=lst_productos.values[4]
                        procesador=lst_productos.values[5]
                        tarjeta=lst_productos.values[6]
                        print (f"Codigo: {codigo}, Marca: {marca}, Pantalla de {pantalla} pulgadas, Ram: {ram}, Tipo de memoria: {tipo_memoria}, Almacenamiento: {almacenamiento}, Procesador: {procesador}, Tarjeta grafica: {tarjeta}")
                        resultado=True
                if not resultado:
                        print ("No hay equipos disponibles dentro de este rango de precio")
        

def actualizar_precio (lst_stock: dict, codigo: str, nuevo_precio: int) -> bool:
        if codigo in lst_stock.keys and nuevo_precio>0:
                nuevo_precio=lst_stock.values[0]
                return True
        return False

#Menú 
menu_activo=True
while menu_activo:
        print ("---Menú de gestión de laptops---")
        print ("1. Consultar stock por marca de laptop")
        print ("2. Buscar productos por rango de precio")
        print ("3. Actualizar precio de un producto")
        print ("4. Salir")
        opcion=input("Selecciona una opción: ")
        if opcion=="1":
                marca=print("Ingresa la marca que deseas buscar: ")
                stock_note=stock_marca(productos,stock,marca)
                print (f"El stock de laptops de la marca buscada es: {stock_note}")
        elif opcion=="2":
                try:
                        precio_min=int(input("Ingresa el precio minimo: $"))
                        precio_max=int(input("Ingresa el preció máximo: $"))
                        if precio_min<0 and precio_max>precio_min:
                                equipos=busqueda_precio(productos,stock,precio_min,precio_max)
                                print (equipos)
                        else:
                                print ("Error. El precio mínimo y máximo deben ser mayor a 0. El precio máximo debe ser mayor al mínimo")
                except ValueError:
                        print ("Preción Inválido. Solo puede ingresar números enteros postivos")
        elif opcion=="3":
                codigo=input("Ingresa el codigo de la laptop: ")
                try:
                        n_precio=int(input("Ingresa el nuevo precio del producto: "))
                        if n_precio>0:
                                cambio_precio=actualizar_precio(stock,codigo,n_precio)
                                if cambio_precio==True:
                                        print ("El precio fue cambiado exitosamente")
                                else:
                                        print ("Fallo al intentar el precio de la laptop. Asegurese que el codigo sea correcto")
                        else:
                                print ("Error. El nueve precio ingresado debe ser mayor a 0")
                except ValueError:
                        print("Error. Solo puedes ingresar un valor entero")
        elif opcion=="4":
                print ("Saliendo del sistema")
                break
        else:
                print ("Opción no válida. Debe ingresar un número entre el 1 al 4")